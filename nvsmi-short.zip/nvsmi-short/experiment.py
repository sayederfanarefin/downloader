import logging

import torch
import pretrainedmodels.utils as utils
import pretrainedmodels
import time
import os
import glob
import time
from multiprocessing.dummy import Pool
import time
from utility_custom import createFolder, listReverseNameOrderFIlesExtensions
from pathlib import Path
from readPower2 import GpuPowerLogger
from pretrainedModelsConfig import modelsConfig
from pathInfo import pathsInfo
from DatasetProfiler import DatasetProfiler
import datetime



def initialize(model_name, dataset):

    global model
    if model_name == "inception_v3":
        model = pretrainedmodels.__dict__[model_name](num_classes=1000, pretrained=dataset, init_weights=True).cuda()
    else:
        model = pretrainedmodels.__dict__[model_name](num_classes=1000, pretrained=dataset).cuda()
        
    model.eval()


def downloadModels(models):
    i = 0
    for model in models:
        logging.info("(" + str(i+1) + " of " + str(len(models)) + ") Downloading pretrained model: " + str(model))
        initialize(model, modelsConfig.get(model))
        i = i+1

def test(model_name, path_img, baseFolder, i):
    global model
    load_img = utils.LoadImage()
    # transformations depending on the model
    # rescale, center crop, normalize, and others (ex: ToBGR, ToRange255)
    tf_img = utils.TransformImage(model) 

    input_img = load_img(path_img)
    input_tensor = tf_img(input_img)         # 3x400x225 -> 3x299x299 size may differ
    input_tensor = input_tensor.unsqueeze(0) # 3x299x299 -> 1x3x299x299
    input = torch.autograd.Variable(input_tensor, requires_grad=False).cuda()

    
    
    # Load Imagenet Synsets
    with open(os.path.join(baseFolder, 'imagenet_synsets.txt'), 'r') as f:
        synsets = f.readlines()

    # len(synsets)==1001
    # sysnets[0] == background
    synsets = [x.strip() for x in synsets]
    splits = [line.split(' ') for line in synsets]
    key_to_classname = {spl[0]:' '.join(spl[1:]) for spl in splits}

    with open(os.path.join(baseFolder, 'imagenet_classes.txt'), 'r') as f:
        class_id_to_key = f.readlines()

    class_id_to_key = [x.strip() for x in class_id_to_key]

    # Make predictions
    output = model(input).cuda() # size(1, 1000)
    max, argmax = output.data.squeeze().max(0)
    class_id = argmax.item()
    class_key = class_id_to_key[class_id]
    classname = key_to_classname[class_key]

    # logging.info("{} > '{}': '{}' is a '{}'".format(str(i), model_name, path_img, classname))


    # output_logits = model(input) # 1x1000

    output_features = model.features(input) # 1x14x14x2048 size may differ
    output_logits = model.logits(output_features) # 1x1000

def unitExperiment(model, powerDataFolder, testDatasetFolder, datasetProfiler, datasetName, gpuPL):
    powerDataFolderPathBuild = os.path.join(powerDataFolder, model)
    createFolder(powerDataFolderPathBuild)
    initialize(model, modelsConfig.get(model))
    i = 0
    # print (listReverseNameOrderFIlesExtensions(os.path.join(testDatasetFolder, "images"), ['jpg', 'JPEG', 'PNG', 'BMP', 'GIF']))
    for file in listReverseNameOrderFIlesExtensions(os.path.join(testDatasetFolder, "images"), ['jpg', 'JPEG', 'PNG', 'BMP', 'GIF']):
        pathToTestImage = os.path.join (testDatasetFolder, "images", file)
        filename, file_extension = os.path.splitext(file)
        pathToStorePowerDataFile = os.path.join (powerDataFolderPathBuild, filename + ".csv")
        
        gpuPL.recordPowerStart(pathToStorePowerDataFile)
        time.sleep(0.02)
        test(model, pathToTestImage, testDatasetFolder, i)
        gpuPL.recordPowerStop(pathToStorePowerDataFile)
        time.sleep(0.1)
        # print ("==> " + testDatasetFolder + " " + model + " " + pathToTestImage)
        i=i+1
    datasetProfiler.datasetTrackerOnComplete(datasetName, model)

def main(powerDataFolders, datasetDir, datasetProfileLogLocation):
    experimentStartTime = datetime.datetime.now().timestamp()
    torch.cuda.is_available()
    
    createFolder(powerDataFolders)
    models = list(modelsConfig.keys())
    datasetProfiler = DatasetProfiler(datasetDir, models, datasetProfileLogLocation)
    
    profileInput = input("Initialize models profiler y/n: ")

    if profileInput == "y":
        datasetProfiler.profile()
    else:
        pass
    
    
    
    downloadModels(models)

    gpuPL = GpuPowerLogger(pathsInfo["pathToStorePowerDataFile"], pathsInfo["powerRecordFilePatha"])
    gpuPL.startPowerReading()

    for testDatasetDir in glob.glob(datasetDir + "\\*\\"):
        # logging.info()
        path = Path(testDatasetDir)
        datasetFolderName = path.parts[-1]
        powerDataFolderPath = os.path.join(powerDataFolders, datasetFolderName)
        createFolder(powerDataFolderPath)

        

        for model in models:
            if not (datasetProfiler.checkDatasetProfile(datasetFolderName, model)):
                logging.info("Experimenting on " + str(datasetFolderName) + " with " + str(model))
                unitExperiment(model, powerDataFolderPath, testDatasetDir, datasetProfiler, datasetFolderName, gpuPL)
            else:
                logging.info("Skipping " + str(datasetFolderName) + " " + str(model))
    
    gpuPL.stopPowerReading()
    del gpuPL
    logging.info("Done with tests")
    
    experimentStopTime = datetime.datetime.now().timestamp()
    
    td = experimentStopTime - experimentStartTime
    td_mins = int(round(td / 60))

    logging.info('Total experiment is approx. %s minutes' % td_mins)




################################################# MAIN #######################################################
if __name__ == '__main__':
    
    logging.basicConfig( format='%(asctime)s %(levelname)-8s %(message)s', level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')
    
    main(pathsInfo["powerDataFolder"], pathsInfo["datasetDir"], pathsInfo["datasetProfileLogLocation"])