# ---------------------------------------------------------------------------- #
#                                    Imports                                   #
# ---------------------------------------------------------------------------- #

import shutil
import os
import natsort 
import glob
import pandas as pd
from datetime import datetime
import _thread
import sys
from pathlib import Path
import uuid
import features
import numpy as np 

# python3 clean_data.py /mnt/c/Users/erfan/Desktop/pytorch_cuda_gpu/power_data_2/ rtx_2060_new clean

def attackBasedCOmbination(modelsOrganized):
    
    training =  ["/mnt/c/Users/erfan/Desktop/cleaned_feature_extracted/training/power_data/combined", "/mnt/c/Users/erfan/Desktop/cleaned_feature_extracted/training/power_data_2/combined"]
    testing = ["/mnt/c/Users/erfan/Desktop/cleaned_feature_extracted/testing/power_data/combined", "/mnt/c/Users/erfan/Desktop/cleaned_feature_extracted/testing/power_data_2/combined"]
    name = ["attack_1", "attack_2", "attack_3"]

# lists files in ascending order given a base folder and the extension
def listNameOrderFIles(pathToFolder, extension):
    os.chdir(pathToFolder)
    dirFiles = glob.glob('*.{}'.format(extension))
    sorted_list = natsort.natsorted(dirFiles,reverse=False)
    # print (sorted_list)
    return sorted_list

#removes the first file ordered in asceding order
def removeOne(baseFolder):
    listOfAll = listNameOrderFIles(baseFolder,  'txt')
    os.remove(os.path.join(baseFolder, listOfAll[0]))

#converts a file to csv
def toJustCSV(filePath):

    filename, file_extension = os.path.splitext(filePath)
    csvFileName = filename + ".csv"
    path = Path(str(filePath))
    newFilePath = os.path.join(path.parent, csvFileName)
    os.rename(filePath, newFilePath) 
    return newFilePath


def convertTotimestamp(currentTime):
    #CHNAGE DATE TO TIMESTAMP
    currentTimeObj = datetime.strptime(currentTime, '%Y-%m-%d %H:%M:%S.%f ')
    currentTimeMiliSec = currentTimeObj.timestamp() 
    # print ("Received Date: " + currentTime + ", Converted time: " + currentTimeMiliSec)
    return currentTimeMiliSec


def listReverseNameOrderFIles(pathToFolder, extension):
    os.chdir(pathToFolder)
    dirFiles = glob.glob('*.{}'.format(extension))
    sorted_list = natsort.natsorted(dirFiles,reverse=True)
    # print (sorted_list)
    return sorted_list



def cleanSpaceAndConvertTime(originalFilePath, tempFilePath):
    print ("> Cleaning spaces and converting time to timestamp: " + originalFilePath)

    filename, file_extension = os.path.splitext(originalFilePath)

    path = Path(str(originalFilePath))
    justFileName = filename.replace(str(path.parent),"")
    justFileName = justFileName.replace("\\","")
    justFileName = justFileName.replace("/","")   

    shutil.copy(originalFilePath, tempFilePath)
    os.remove(originalFilePath)
    try:
        df = pd.read_csv(tempFilePath)

        df.columns = ['date', 'gpu_clock', 'gpu_load','power_draw_board', 'power_gpu_chip', 'power_mvddc', 'power_pcie_slot', 'voltage_pcie_slot', 'power_8_pin', 'voltage_8_pin', 'power_consumption_tdp', 'voltage_gpu']
        
        df['sample'] = str(justFileName)
        df['date'] = df['date'].apply(lambda x: convertTotimestamp(x))
        del df['gpu_clock']
        del df['gpu_load']
        del df['voltage_pcie_slot']
        del df['voltage_8_pin']
        del df['voltage_gpu']

        df.to_csv(originalFilePath,  index=False)
    except:
        print (">>>>>> Exception reading this: " + tempFilePath)
        
    os.remove(tempFilePath)

def cleanComma(fileName, newFileName):
    print ("> Cleaning last comma: " + fileName)
    with open(fileName, 'r') as r, open(newFileName, 'w') as w:    
        for num, line in enumerate(r):
            if num >= 0:            
                newline = line[:-2] + "\n" if "\n" in line else line[:-1]
            else:
                newline = line               
            w.write(newline)


def createFolder(pathToFolder):    
    try:
        os.mkdir(pathToFolder)
    except OSError:
        print (".")
    else:
        print ("> Successfully created the directory %s " % pathToFolder)



def runCommand(commandToRun):
    # print ("===> Running command: " + commandToRun)
    os.system(commandToRun)

def compareAndSave(reducingContentFile, targetFile, reducedFile):

    if reducingContentFile!=targetFile:
        command = "grep -vxFf "+ reducingContentFile +" " + targetFile +">" + reducedFile
        runCommand(command)



def combinecsvs(baseFolder, combinedCSVPath):
    
    #combine all files in the list
    combinedCsv = pd.concat([pd.read_csv(f) for f in listNameOrderFIles(baseFolder,  'csv') ])
    #export to csv
    combinedCsv.to_csv( combinedCSVPath, index=False)
    print ("> Combined csv saved at: ", combinedCSVPath)

def cleanerMainMother(baseFolder):

    #create temp folder
    tempFolder = os.path.join(baseFolder ,"temp")
    createFolder(tempFolder)

    # replace contents
    try:
        os.rename(os.path.join(baseFolder, "00garbage.txt"), os.path.join(baseFolder, "00.txt"))
    except: 
        print ("Now only Allah knows, what went wrong")

    # renaming files"
    length = len(listReverseNameOrderFIles(baseFolder,  'txt')) - 1

    for file in listReverseNameOrderFIles(baseFolder,  'txt'):
        originalFile = os.path.join(baseFolder, file)
        newFile = os.path.join(baseFolder, str(length) + ".txt")
        os.rename(originalFile, newFile)
        length = length - 1

    print ("File renaming done.")
    
    # reducing files: 
    i = 0
    files = listReverseNameOrderFIles(baseFolder,  'txt')
    for file in files:
        if i < len (files) -1:
            targetFile = os.path.join(baseFolder, file)     
            replacingContentFile = os.path.join(baseFolder, files[i+1])     
            tempFile = os.path.join(tempFolder,     str(uuid.uuid4()) + "xxx.txt")
            shutil.copy(targetFile, tempFile )
            os.remove(targetFile)

            print ("> Reducing file: " + targetFile)
            compareAndSave(replacingContentFile , tempFile, targetFile)
            os.remove(tempFile)

        i = i+1

    #remove the garbage file which is now 0.txt
    removeOne(baseFolder)

    # copy original file -> temp file
    # delete original file
    # clean comma of the orignal file from temp -> original directory
    # delete temp file

    
    for file in listReverseNameOrderFIles(baseFolder,  'txt'):
        originalFile = os.path.join(baseFolder, file)
        tempFile = os.path.join(tempFolder, file)
        shutil.copy(originalFile, tempFile)
        os.remove(originalFile)
        cleanComma(tempFile, originalFile)
        os.remove(tempFile)
        csvFilePath = toJustCSV(originalFile)
        cleanSpaceAndConvertTime(csvFilePath, os.path.join(tempFolder, str(uuid.uuid4()) + "xxxx.csv") )
    # removing the temp folder
    os.rmdir(tempFolder)

def addTypeToCombinedFile(combinedFile, modelName):
    df= pd.read_csv(str(combinedFile))
    df["type"] = modelName
    df.to_csv(combinedFile, index=False)
    print (">>> Added type to the file and saved it here: " + combinedFile)


def getCombinedFileName(combinedFolder, model):
    return os.path.join(combinedFolder, model + "_combined_csv.csv")

def getFeatureExtractFileName(featureExtractFolder, model):
    return os.path.join(featureExtractFolder, model + "_features.csv")

def extractFeatures(combinedFile, featureFile):
    features.extractFeatures(combinedFile, featureFile)
    print ("> Feature extraction done and saved at: ", featureFile)

def cleanColumns(combinedCSVPath):
    df3 = pd.read_csv(combinedCSVPath)
    df3.replace('', np.nan, inplace=True)
    df3.replace([np.inf, -np.inf], np.nan, inplace=True)

    df3.dropna(
        axis=1,
        inplace=True
    )

    # drop columns where value variation is 1
    nunique = df3.apply(pd.Series.nunique)
    cols_to_drop = nunique[nunique == 1].index
    df3 = df3.drop(cols_to_drop, axis=1)

    # # drop columns where value variation is 2
    # cols_to_drop = nunique[nunique == 2].index
    # df3 = df3.drop(cols_to_drop, axis=1)

    # # drop columns where value variation is 3
    # cols_to_drop = nunique[nunique == 3].index
    # df3 = df3.drop(cols_to_drop, axis=1)
    df3.to_csv( combinedCSVPath, index=False)

def featureSubFolder(baseFeatureFolder, modelname):
    return os.path.join(baseFeatureFolder ,modelname)

if __name__ == '__main__':
    models = ["alexnet", "polynet",  "xception", "nasnetalarge", "nasnetamobile", "pnasnet5large", "squeezenet1_0", "squeezenet1_1", "vgg11_bn", "vgg13_bn", "vgg16_bn","vgg19_bn", "vgg11", "vgg16","vgg19", "vgg13", "densenet121", "densenet161","densenet169","densenet201", "bninception",  "inceptionv3", "inceptionv4", "dpn68", "dpn68b", "dpn92", "dpn98",  "dpn131",  "resnet18", "resnet34", "resnet50", "resnet101", "resnet152", "fbresnet152", "cafferesnet101", "se_resnet50", "se_resnet101", "se_resnet152", "se_resnext101_32x4d"]
   
    modelsOrganized = [
        ["alexnet", "densenet121", "dpn131", "polynet", "vgg19", "inceptionv4", "resnet152", "nasnetalarge", "squeezenet1_1", "xception"],
        ["nasnetalarge", "nasnetamobile", "pnasnet5large", "squeezenet1_0", "squeezenet1_1", "vgg11_bn", "vgg13_bn", "vgg16_bn","vgg19_bn", "vgg11", "vgg16","vgg19", "vgg13", "densenet121", "densenet161","densenet169","densenet201", "bninception",  "inceptionv3", "inceptionv4", "dpn68", "dpn68b", "dpn92", "dpn98",  "dpn131",  "resnet18", "resnet34", "resnet50", "resnet101", "resnet152", "fbresnet152", "cafferesnet101", "se_resnet50", "se_resnet101", "se_resnet152", "se_resnext101_32x4d"],
        ["nasnetalarge", "nasnetamobile", "pnasnet5large", "squeezenet1_0", "squeezenet1_1", "vgg11_bn", "vgg13_bn", "vgg16_bn","vgg19_bn", "vgg11", "vgg16","vgg19", "vgg13", "densenet121", "densenet161","densenet169","densenet201", "bninception",  "inceptionv3", "inceptionv4", "dpn68", "dpn68b", "dpn92", "dpn98",  "dpn131",  "resnet18", "resnet34", "resnet50", "resnet101", "resnet152", "fbresnet152", "cafferesnet101", "se_resnet50", "se_resnet101", "se_resnet152", "se_resnext101_32x4d"]
       
        ]
    
    forMixes=["attack_1", "attack_2", "attack_3"]

    

    #create temp folder
    combinedFolder = os.path.join(str(sys.argv[1]) ,"combined")

    if sys.argv[3]=="clean":

        createFolder(combinedFolder)
        
        for model in models:
            folderForTargetNetworkTyoePowerData = os.path.join(str(sys.argv[1]), model )
            print (">>> Processing file: " + model, folderForTargetNetworkTyoePowerData)
            cleanerMainMother(folderForTargetNetworkTyoePowerData)
            print (">>> Combining CSVs")
            combinecsvs(folderForTargetNetworkTyoePowerData, getCombinedFileName(combinedFolder, model))
            addTypeToCombinedFile(getCombinedFileName(combinedFolder, model), model)
            
    if sys.argv[3]=="combine":
        createFolder(combinedFolder)

        for model in models:
            folderForTargetNetworkTyoePowerData = os.path.join(str(sys.argv[1]), model)
            print (">>> Combining CSVs")
            combinecsvs(folderForTargetNetworkTyoePowerData, getCombinedFileName(combinedFolder, model))
            addTypeToCombinedFile(getCombinedFileName(combinedFolder, model), model)

    feattureExtractFolder = os.path.join(str(sys.argv[1]) ,"features")
    feattureExtractFolderAll =  os.path.join(feattureExtractFolder ,"all")

    createFolder(feattureExtractFolder)
    createFolder(feattureExtractFolderAll)

    for model in models:
        # extract features
        extractFeatures(getCombinedFileName(combinedFolder, model), getFeatureExtractFileName(feattureExtractFolderAll, model))
        

    #### create sub folder and combine the features now

    for model in forMixes:
        createFolder(featureSubFolder(feattureExtractFolder, model))

    iii=0

    for modelx in forMixes:
        # organizing feature files
        for model in modelsOrganized[iii]:
            # extract features
            print(modelx, model)
            shutil.copy( getFeatureExtractFileName(feattureExtractFolderAll, model), getFeatureExtractFileName(featureSubFolder(feattureExtractFolder, modelx), model))

        print (">>> Combine all features")
        pathToRawFeatures=os.path.join(str(sys.argv[1]), str(sys.argv[2]) + "_raw_"+ modelx +"_features.csv")
        combinecsvs(featureSubFolder(feattureExtractFolder, modelx), pathToRawFeatures)
        cleanColumns(pathToRawFeatures)
        
        iii=iii+1
    






    # organizing feature files
    # for model in modelsOrganized[0]:
    #     # extract features
    #     shutil.copy( getFeatureExtractFileName(feattureExtractFolderAll, model), getFeatureExtractFileName(feattureExtractSubFolderRaw, model))

    # for model in modelsOrganized[1]:
    #     # extract features
    #     shutil.copy( getFeatureExtractFileName(feattureExtractFolderAll, model), getFeatureExtractFileName(feattureExtractSubFolderLayeredResnet, model))

    # for model in modelsOrganized[2]:
    #     # extract features
    #     shutil.copy( getFeatureExtractFileName(feattureExtractFolderAll, model), getFeatureExtractFileName(feattureExtractSubFolderMixInception, model))

    # for model in modelsOrganized[3]:
    #     # extract features
    #     shutil.copy( getFeatureExtractFileName(feattureExtractFolderAll, model), getFeatureExtractFileName(feattureExtractSubFolderMixResnet, model))


    # print (">>> Combine all features")
    # pathToRawFeatures=os.path.join(str(sys.argv[1]), str(sys.argv[2]) + "_raw_all_features.csv")
    # combinecsvs(feattureExtractFolderAll, pathToRawFeatures)
    # cleanColumns(pathToRawFeatures)
    
    print (">>> Done with everything!")
