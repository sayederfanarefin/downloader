# nvidia-smi -i 0 --loop-ms=10 --format=csv,noheader --query-gpu=timestamp,power.draw


import subprocess
import os, signal
import logging
import time
import threading

class GpuPowerLogger:

    def threaded(fn):
        def wrapper(*args, **kwargs):
            threading.Thread(target=fn, args=args, kwargs=kwargs).start()
        return wrapper

    def executePowerCommand(self):
        cmd = "nvidia-smi -i 0 --loop-ms=10 --format=csv,noheader --query-gpu=timestamp,power.draw"
        processx = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
            
        self.id = processx.pid
        # logging.info('Power logger started')
        
        for stdout_line in iter(processx.stdout.readline, ""):
            yield stdout_line 
        processx.stdout.close()
        return_code = processx.wait()
        if return_code:
            raise subprocess.CalledProcessError(return_code, cmd)

    @threaded
    def startPowerReading(self):
        self.powerFile = open(self.powerFilePath, "wb")
        for path in self.executePowerCommand():
            try:
                self.powerFile.write(path)
                # print(path, end="")
            except:
                pass


    def stopPowerReading(self):
        try:
            self.powerFile.close()
        
        except:
            pass
        
        os.kill(self.id, -1)
        # logging.info('Power logger stopped')

    def __init__(self, powerFilePath):
        self.powerFilePath = powerFilePath
        logging.basicConfig( format='%(asctime)s %(levelname)-8s %(message)s', level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')
    


        
        
        


# if __name__ == '__main__':
    
    
#     gpuPL = GpuPowerLogger("dummy.csv")
#     gpuPL.startPowerReading()
#     time.sleep(2)
#     gpuPL.stopPowerReading()

#     del gpuPL
#     gpuPL = GpuPowerLogger("dummy2.csv")
#     gpuPL.startPowerReading()
#     time.sleep(2)
#     gpuPL.stopPowerReading()
#     del gpuPL


    


    