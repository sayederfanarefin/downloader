#!/usr/bin/env python
# coding: utf-8


####################################################################################### imports #######################################################################################


import pandas as pd 
import numpy as np 
from datetime import datetime
import _thread

import torch
import pretrainedmodels.utils as utils
import pretrainedmodels
import time
import os
import natsort 
import glob
import time
from multiprocessing.dummy import Pool
import time

torch.cuda.is_available()



#################################################################################################################################################
#################################################################################################################################################
#################################################################################################################################################
#data collection stuff

model = None

    
def listReverseNameOrderFIles(pathToFolder, extension):
    os.chdir(pathToFolder)
    dirFiles = glob.glob('*.{}'.format(extension))
    sorted_list = natsort.natsorted(dirFiles,reverse=False)
    #print (sorted_list)
    return sorted_list
    
def createFolder(folderPath):
    try:
        os.mkdir(folderPath)
    except OSError:
        print ("Directory may already exist: Creation of the directory %s failed" % folderPath)
    else:
        print ("Successfully created the directory %s " % folderPath)



def initialize(model_name, dataset):

    global model
    model = pretrainedmodels.__dict__[model_name](num_classes=1000, pretrained=dataset).cuda()
    model.eval()

    


def test(model_name, path_img, baseFolder, i):
    global model
    load_img = utils.LoadImage()
    # transformations depending on the model
    # rescale, center crop, normalize, and others (ex: ToBGR, ToRange255)
    tf_img = utils.TransformImage(model) 

    input_img = load_img(path_img)
    input_tensor = tf_img(input_img)         # 3x400x225 -> 3x299x299 size may differ
    input_tensor = input_tensor.unsqueeze(0) # 3x299x299 -> 1x3x299x299
    input = torch.autograd.Variable(input_tensor, requires_grad=False).cuda()

    
    
    # Load Imagenet Synsets
    with open(os.path.join(baseFolder, 'imagenet_synsets.txt'), 'r') as f:
        synsets = f.readlines()

    # len(synsets)==1001
    # sysnets[0] == background
    synsets = [x.strip() for x in synsets]
    splits = [line.split(' ') for line in synsets]
    key_to_classname = {spl[0]:' '.join(spl[1:]) for spl in splits}

    with open(os.path.join(baseFolder, 'imagenet_classes.txt'), 'r') as f:
        class_id_to_key = f.readlines()

    class_id_to_key = [x.strip() for x in class_id_to_key]

    # Make predictions
    output = model(input).cuda() # size(1, 1000)
    max, argmax = output.data.squeeze().max(0)
    class_id = argmax.item()
    class_key = class_id_to_key[class_id]
    classname = key_to_classname[class_key]

    print("{} > '{}': '{}' is a '{}'".format(str(i), model_name, path_img, classname))


    # output_logits = model(input) # 1x1000

    output_features = model.features(input) # 1x14x14x2048 size may differ
    output_logits = model.logits(output_features) # 1x1000

def main(modelName, dataset, baseFolder, folderToStorePowerData, pathToLogFile, ext):
    # alexnet, densenet121, polynet, vgg19, inceptionv4, resnet18, resnet101, resnet152, inceptionresnetv2, fbresnet152, se_resnet152
    initialize(modelName, dataset)
    i = 0
    copyPowerDataFromMainLog(pathToLogFile, os.path.join (folderToStorePowerData, "00garbage.txt"))
    for file in listReverseNameOrderFIles(os.path.join(baseFolder, "images"), ext):
        path = os.path.join (baseFolder, "images", file)
        filename, file_extension = os.path.splitext(file)
        pathToStorePowerDataFile = os.path.join (folderToStorePowerData, filename + ".txt")
#         print(modelName + ", Testing: " + str (path))
        test(modelName, path, baseFolder, i)
        copyPowerDataFromMainLog(pathToLogFile, pathToStorePowerDataFile)
        time.sleep(2)
        i=i+1

def downloadModels(models, datasets):
    i = 0
    for model in models:
        print (">>> (" + str(i) + " of " + str(len(models)) + " ) Downloading pretrained model: " + str(model))
        initialize(model, datasets[i])
        i = i+1

def modelsIterator(models, datasets, baseFolder, powerDataBaseFolder, pathToLogFile, ext):
    createFolder(powerDataBaseFolder)
    i=0
    
    for model in models:
        startGpuz()
        print (">>> Running pretrained: " + str(model))
        folderToStorePowerData = os.path.join(powerDataBaseFolder, model)
        createFolder(folderToStorePowerData)
        main(model, datasets[i], baseFolder, folderToStorePowerData, pathToLogFile, ext)
        killGpuz()
        removeLogFile(pathToLogFile)
        i=i+1
        
    print (">>> Finished data collection.")
    
##############################################################################################################
################################################# MAIN #######################################################
if __name__ == '__main__':
    
    

    #unique networks
    # models = ["alexnet", "densenet121", "dpn131", "polynet", "vgg19", "inceptionv4", "resnet152", "nasnetalarge", "squeezenet1_1", "xception"]

    #All
    # models = ["alexnet", "densenet121", "dpn131", "polynet", "vgg11", "inceptionv4", "resnet18", "nasnetalarge", "squeezenet1_1", "xception", "resnet18", "resnet34", "resnet50", "resnet101", "bninception", "inceptionv4", "cafferesnet101", "inceptionresnetv2", "fbresnet152", "se_resnet152", "se_resnext101_32x4d"]
    # "dpn92", "dpn107""dpn113",  "senet154",
    # models = ["alexnet", "dpn131", "polynet", "vgg11", "inceptionv4", "resnet18", "nasnetalarge", "squeezenet1_1", "xception", "densenet121", "squeezenet1_0",  "resnet18", "densenet161","densenet169","densenet201", "dpn68", "dpn98", "vgg13", "dpn131", "vgg16","vgg19", "resnet34", "resnet50", "resnet101", "bninception",  "inceptionv3","cafferesnet101", "inceptionresnetv2", "fbresnet152", "se_resnet152", "se_resnext101_32x4d"]
    
    ################################variants
    ### previous
    models = ["alexnet", "polynet",  "xception", "nasnetalarge", "nasnetamobile", "pnasnet5large", "squeezenet1_0", "squeezenet1_1", "vgg11_bn", "vgg13_bn", "vgg16_bn","vgg19_bn", "vgg11", "vgg16","vgg19", "vgg13", "densenet121", "densenet161","densenet169","densenet201", "bninception",  "inceptionv3", "inceptionv4", "dpn68", "dpn68b", "dpn92", "dpn98",  "dpn131",  "resnet18", "resnet34", "resnet50", "resnet101", "resnet152", "fbresnet152", "cafferesnet101", "se_resnet50", "se_resnet101", "se_resnet152", "se_resnext101_32x4d"]
    datasets=['imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet', 'imagenet+5k', 'imagenet+5k', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet','imagenet','imagenet','imagenet','imagenet','imagenet','imagenet']
    #all:: ===================>


    # datasets=['imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet+5k', 'imagenet+5k', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet', 'imagenet']
    # models = [ "resnet152", "vgg11_bn", "vgg13_bn", "vgg16_bn","vgg19_bn", "dpn68b", "dpn92", "nasnetamobile", "resnext101_32x4d", "pnasnet5large", "se_resnet50", "se_resnet101", "se_resnext50_32x4d"]
    


    # downloadModels(models, datasets)
    modelsIterator(models, datasets, 'C:\\Users\\erfan\\Desktop\\pytorch_cuda_gpu\\data2', 'C:\\Users\\erfan\\Desktop\\pytorch_cuda_gpu\\power_data_2', "C:\\Users\\erfan\\Desktop\\GPU-Z Sensor Log.txt", 'JPEG')
    modelsIterator(models, datasets, 'C:\\Users\\erfan\\Desktop\\pytorch_cuda_gpu\\data', 'C:\\Users\\erfan\\Desktop\\pytorch_cuda_gpu\\power_data', "C:\\Users\\erfan\\Desktop\\GPU-Z Sensor Log.txt", 'jpg')
    