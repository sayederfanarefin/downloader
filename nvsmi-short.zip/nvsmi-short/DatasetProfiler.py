from collections import defaultdict
import pandas as pd
import numpy as np
import json
import logging
import os

class DatasetProfiler:
    
    def readLogFile(self):
        with open(self.datasetProfileLogLocation) as f:
            data = f.read()
            
        return json.loads(data)

    def checkDatasetProfile(self, datasetName, pretrainedModel):
        log = self.readLogFile()
        # print (log[datasetName][pretrainedModel])
        if log[datasetName][pretrainedModel] == 0:
            return False

        else:
            return True
        

    def profile(self):
        logging.info("Profiling the datasets for record")
        #  the header are going to be the pre trained models 
        # the left most index will be the dataset names
        
        
        datasetModelProfileDict = defaultdict(dict)
        for dataset in next(os.walk(self.datasetDir))[1]:
            for model in self.models:
                datasetModelProfileDict[dataset][model] = 0
        
        with open(self.datasetProfileLogLocation, 'w') as f:
            json.dump(datasetModelProfileDict, f)

        logging.info("DatasetProfiling done")




    def datasetTrackerOnComplete(self, datasetName, pretrainedModel):
        log = self.readLogFile()
        log[datasetName][pretrainedModel] = 1
        with open(self.datasetProfileLogLocation, 'w') as f:
            json.dump(log, f)


    def __init__(self, datasetDir, models, datasetProfileLogLocation):
        self.datasetDir = datasetDir
        self.models = models
        self.datasetProfileLogLocation = datasetProfileLogLocation
        logging.basicConfig( format='%(asctime)s %(levelname)-8s %(message)s', level=logging.INFO, datefmt='%Y-%m-%d %H:%M:%S')
    
