import pandas as pd 
import numpy as np 
import tsfresh
import warnings

#updated
def FeatureSpectralDecrease(X, f_s):
    # compute index vector
    kinv = np.arange(0, X.shape[0])
    kinv[0] = 1
    kinv = 1 / kinv

    norm = X[1:].sum(axis=0, keepdims=True)
    norm[norm == 0] = 1

    # compute slope
    vsc = np.dot(kinv, X - X[0]) / norm

    return np.squeeze(vsc, axis=0)
    
#updated
def FeatureSpectralCentroid(X, f_s):

    isSpectrum = X.ndim == 1
    norm = X.sum(axis=0, keepdims=True)
    norm[norm == 0] = 1

    vsc = np.dot(np.arange(0, X.shape[0]), X) / norm

    # convert from index to Hz
    vsc = vsc / (X.shape[0] - 1) * f_s / 2

    # if input is a spectrum, output scaler else if spectrogram, output 1d array
    vsc = np.squeeze(vsc) if isSpectrum else np.squeeze(vsc, axis=0)

    return vsc

#updated
def FeatureSpectralSpread(X, f_s):

    isSpectrum = X.ndim == 1
    if isSpectrum:
        X = np.expand_dims(X, axis=1)

    # get spectral centroid as index
    vsc = FeatureSpectralCentroid(X, f_s) * 2 / f_s * (X.shape[0] - 1)

    # X = X**2 removed for consistency with book

    norm = X.sum(axis=0)
    norm[norm == 0] = 1

    # compute spread
    vss = np.zeros(X.shape[1])
    indices = np.arange(0, X.shape[0])
    for n in range(0, X.shape[1]):
        vss[n] = np.dot((indices - vsc[n])**2, X[:, n]) / norm[n]

    vss = np.sqrt(vss)

    # convert from index to Hz
    vss = vss / (X.shape[0] - 1) * f_s / 2

    return np.squeeze(vss) if isSpectrum else vss

#updated
def FeatureSpectralKurtosis(X, f_s, UseBookDefinition=False):

    isSpectrum = X.ndim == 1
    if isSpectrum:
        X = np.expand_dims(X, axis=1)

    if UseBookDefinition:  # not recommended
        # compute mean and standard deviation
        mu_x = np.mean(X, axis=0, keepdims=True)
        std_x = np.std(X, axis=0)

        # remove mean
        X = X - mu_x

        # compute kurtosis
        vsk = np.sum(X**4, axis=0) / (std_x**4 * X.shape[0])
    else:
        f = np.arange(0, X.shape[0]) / (X.shape[0] - 1) * f_s / 2
        # get spectral centroid and spread (mean and std of dist)
        vsc = FeatureSpectralCentroid(X, f_s)  # *2/f_s * (X.shape[0]-1)
        vss = FeatureSpectralSpread(X, f_s)    # *2/f_s * (X.shape[0]-1)

        norm = X.sum(axis=0)
        norm[norm == 0] = 1
        vss[vss == 0] = 1

        # compute kurtosis
        vsk = np.zeros(X.shape[1])
        for n in range(0, X.shape[1]):
            vsk[n] = np.dot((f - vsc[n])**4, X[:, n]) / (vss[n]**4 * norm[n] * X.shape[0])

    return np.squeeze(vsk - 3) if isSpectrum else (vsk - 3)


def FeatureSpectralSkewness(X, f_s):
    mu_x = np.mean(X, axis=0, keepdims=False)
    std_x = np.std(X, axis=0)

        # remove mean
    X = X - mu_x

        # compute kurtosis
    vssk = np.sum(X**3, axis=0) / (std_x**3 * X.shape[0])

    return (vssk)




def FeatureSpectralRolloff(X, f_s, kappa=0.85):

    norm = X.sum(axis=0, keepdims=True)
    norm[norm == 0] = 1

    X = np.cumsum(X, axis=0) / norm

    vsr = np.argmax(X >= kappa, axis=0)

    # convert from index to Hz
    vsr = vsr / (X.shape[0] - 1) * f_s / 2

    return vsr


def FeatureSpectralSlope(X, f_s):

    # compute mean
    mu_x = X.mean(axis=0, keepdims=False)

    # compute index vector
    kmu = np.arange(0, X.shape[0]) - X.shape[0] / 2

    # compute slope
    X = X - mu_x
    vssl = np.dot(kmu, X) / np.dot(kmu, kmu)

    return (vssl)

################################################################

def TFAbsEnergy(X):
    return tsfresh.feature_extraction.feature_calculators.abs_energy(X)

def TFABSSumOfChanges(X):    
    return tsfresh.feature_extraction.feature_calculators.absolute_sum_of_changes(X)

def TFKurtosis(X):
    return tsfresh.feature_extraction.feature_calculators.kurtosis(X)

def TFSampleEntropy(X):
    return tsfresh.feature_extraction.feature_calculators.sample_entropy(X)

def TFAutoCorelation(X):
    return tsfresh.feature_extraction.feature_calculators.autocorrelation(X,2)

def TFC3(X):
    return tsfresh.feature_extraction.feature_calculators.c3(X,2)

def TFCidCe(X):
    return tsfresh.feature_extraction.feature_calculators.cid_ce(X,False)

def TFMeanAbsEnergy(X):
    return tsfresh.feature_extraction.feature_calculators.mean_abs_change(X)

def TFMeanChange(X):
    return tsfresh.feature_extraction.feature_calculators.mean_change(X)


    #return tsfresh.feature_extraction.feature_calculators.fourier_entropy(yyy, 1)

def TFLongestStrickeAboveMean(X):
    return tsfresh.feature_extraction.feature_calculators.longest_strike_above_mean(X)

def TFLongestStrikeBelowMean(X):
    return tsfresh.feature_extraction.feature_calculators.longest_strike_below_mean(X)


#################### NEW STUFF #################
def TFStandardDeviation(X):
    return tsfresh.feature_extraction.feature_calculators.standard_deviation(X)

# def TFApproximateEntropy(x):
#     return tsfresh.feature_extraction.feature_calculators.approximate_entropy(x,10000, 100.5)

def TFBenfordCorrelation(x):
    return tsfresh.feature_extraction.feature_calculators.benford_correlation(x)

def TFBinnedEntropy(x):
    return tsfresh.feature_extraction.feature_calculators.binned_entropy(x,10)

def TFCountAboveMean(x):
    return tsfresh.feature_extraction.feature_calculators.count_above_mean(x)

# def TFCountBelowMean(x):
#     return tsfresh.feature_extraction.feature_calculators.count_below_mean(x)

def TFFourierEntropy(x):
    return tsfresh.feature_extraction.feature_calculators.fourier_entropy(x, 15)

def TFHasDuplicate(x):
    return tsfresh.feature_extraction.feature_calculators.has_duplicate(x)

def TFHasDuplicateMax(x):
    return tsfresh.feature_extraction.feature_calculators.has_duplicate_max(x)

def TFHasDuplicateMin(x):
    return tsfresh.feature_extraction.feature_calculators.has_duplicate_min(x)

def TFLargeStandardDeviation(x):
    return tsfresh.feature_extraction.feature_calculators.large_standard_deviation(x, 10)

def TFLastLocationOfMaximum(x):
    return tsfresh.feature_extraction.feature_calculators.last_location_of_maximum(x)  

def TFLastLocationOfMinimum(x):
    return tsfresh.feature_extraction.feature_calculators.last_location_of_minimum(x) 

def TFLempelZivComplexity(x):
    return tsfresh.feature_extraction.feature_calculators.lempel_ziv_complexity(x,2) 

# def TFMaxLangevinFixedPoint(x):
#     return tsfresh.feature_extraction.feature_calculators.max_langevin_fixed_point(x,2, 10.5) 

# def TFMaximum(x):
#     return tsfresh.feature_extraction.feature_calculators.maximum(x) 

# def TFMean(x):
#     return tsfresh.feature_extraction.feature_calculators.mean(x) 

def TFMeanAbsChange(x):
    return tsfresh.feature_extraction.feature_calculators.mean_abs_change(x) 

def TFMeanSecondDerivativeCentral(x):
    return tsfresh.feature_extraction.feature_calculators.mean_second_derivative_central(x) 

# def TFMedian(x):
#     return tsfresh.feature_extraction.feature_calculators.median(x) 

def TFMinimum(x):
    return tsfresh.feature_extraction.feature_calculators.minimum(x) 

def TFSkewness(x):
    return tsfresh.feature_extraction.feature_calculators.skewness(x) 

def TFVariance(x):
    return tsfresh.feature_extraction.feature_calculators.variance(x) 

def TFVarianceLargerThanStandardDeviation(x):
    return tsfresh.feature_extraction.feature_calculators.variance_larger_than_standard_deviation(x) 

def TFVariationCoefficient(x):
    return tsfresh.feature_extraction.feature_calculators.variation_coefficient(x) 


def extractFeatures(inputFile, outputFile):
    warnings.simplefilter("error")
    df = pd.read_csv(inputFile) 
    #print(df)
    
    # First grouping based on "id" 
    # Within each team we are grouping based on "x" 

    df.replace(r'^\s*$', np.nan, regex=True, inplace=True)

    df.replace('', np.nan, inplace=True)
    df.replace([np.inf, -np.inf], np.nan, inplace=True)

    df.dropna(
        axis=0,
        how='any',
        thresh=None,
        subset=None,
        inplace=True
    )
    
    df.type = df.type.astype(str)
    # df.power_gpu_chip = df.power_gpu_chip.astype(float)
    # df.power_mvddc = df.power_mvddc.astype(float)
    # df.voltage_pcie_slot = df.voltage_pcie_slot.astype(float)
    # df.power_8_pin = df.power_8_pin.astype(float)
    # df.voltage_8_pin = df.voltage_8_pin.astype(float)
    # df.power_consumption_tdp = df.power_consumption_tdp.astype(float)
    # df.power_pcie_slot = df.power_pcie_slot.astype(float)


    gkk = df.groupby(['type','sample'])

    s_rate_arr= df['date'].unique()
    f_s = len(s_rate_arr)

    # f = {'power_gpu_chip':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  lambda x: TFMeanChange(x) ],
    # 'gpu_clock':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), lambda x: TFSampleEntropy(x)], 
    # 'gpu_load':[ lambda x: TFSampleEntropy(x)], 
    # 'voltage_pcie_slot':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), lambda x: TFC3(x)], 
    # 'power_8_pin':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  lambda x: TFMeanChange(x)], 
    # 'voltage_8_pin':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  lambda x: TFMeanChange(x)], 
    # 'power_consumption_tdp':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  lambda x: TFMeanChange(x)], 
    # 'power_draw_board':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  lambda x: TFMeanChange(x)], 
    # 'power_mvddc':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), lambda x: TFC3(x) ], 
    # 'voltage_gpu':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), lambda x: TFC3(x)], 
    # 'power_pcie_slot':[ ('AbsEnergy', lambda x: TFAbsEnergy(x)), lambda x: TFABSSumOfChanges(x), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  lambda x: TFMeanChange(x)]}


    # f = {'power_gpu_chip':[  ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))],
    # 'power_8_pin':[          ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    # 'power_consumption_tdp':[('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    # 'power_draw_board':[     ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    # 'power_mvddc':[          ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    # 'power_pcie_slot':[      ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('SampleEntropy', lambda x: TFSampleEntropy(x)), ('AutoCorelation', lambda x: TFAutoCorelation(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))]}

    f = {'power_gpu_chip':[  ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)), ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)), ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)),  ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)), ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))],
    'power_8_pin':[          ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)), ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)),  ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    'power_consumption_tdp':[('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    'power_draw_board':[     ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BenfordCorrelation', lambda x: TFBenfordCorrelation(x)), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)),   ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)),  ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    'power_mvddc':[          ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)), ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)),  ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))], 
    'power_pcie_slot':[      ('StandardDeviation', lambda x: TFStandardDeviation(x) ), ('BinnedEntropy', lambda x: TFBinnedEntropy(x)), ('CountAboveMean', lambda x: TFCountAboveMean(x)), ('HasDuplicateMax', lambda x: TFHasDuplicateMax(x)),  ('HasDuplicateMin', lambda x: TFHasDuplicateMin(x)), ('LargeStandardDeviation', lambda x: TFLargeStandardDeviation(x)), ('LastLocationOfMaximum', lambda x: TFLastLocationOfMaximum(x)), ('LastLocationOfMinimum', lambda x: TFLastLocationOfMinimum(x)), ('LempelZivComplexity', lambda x: TFLempelZivComplexity(x)),  ('MeanSecondDerivativeCentral', lambda x: TFMeanSecondDerivativeCentral(x)),  ('Minimum', lambda x: TFMinimum(x)), ('Skewness', lambda x: TFSkewness(x)), ('Variance', lambda x: TFVariance(x)), ('VarianceLargerThanStandardDeviation', lambda x: TFVarianceLargerThanStandardDeviation(x)), ('VariationCoefficient', lambda x: TFVariationCoefficient(x)), ('AbsEnergy', lambda x: TFAbsEnergy(x)), ('Kurtosis', lambda x: TFKurtosis(x)), ('C3', lambda x: TFC3(x)), ('CidCe', lambda x: TFCidCe(x)),  ('MeanChange', lambda x: TFMeanChange(x)), ('ABSSumOfChanges', lambda x: TFABSSumOfChanges(x))]}



    gg = gkk.agg(f)
    gg.to_csv(outputFile)
    df2 = pd.read_csv(outputFile, header=[0,1])

    combinedTitle = []
    for col in df2.columns: 
        combinedTitle.append(col[0] + "__" + col[1]) 
    df2.columns = combinedTitle

    df2.to_csv(outputFile,  index=False)

    df3 = pd.read_csv(outputFile)
    df3 = df3.iloc[1:]
    df3 = df3.rename(columns = {'Unnamed: 0_level_0__Unnamed: 0_level_1':'type'})
    df3 = df3.rename(columns = {'Unnamed: 1_level_0__Unnamed: 1_level_1':'sample'})

    
    df3.to_csv(outputFile,  index=False)

    # power_gpu_chip: MeanSecondDerivativeCentral, Skewness, Kurtosis, AutoCorelation, MeanChange, 
    # 8-pin: HasDuplicateMax, MeanSecondDerivativeCentral, Skewness, Kurtosis, AutoCorelation, MeanChange
    # tdp: MeanSecondDerivativeCentral, Skewness, Kurtosis, AutoCorelation, MeanChange
    # power_draw_board: BenfordCorrelation, MeanSecondDerivativeCentral, Skewness, Kurtosis, AutoCorelation, MeanChange
    # mvddc: LargeStandardDeviation, MeanSecondDerivativeCentral, Skewness, Kurtosis, AutoCorelation, MeanChange
    # pcie: MeanSecondDerivativeCentral, Skewness, Kurtosis, AutoCorelation, MeanChange


    # power_gpu_chip__Minimum, power_8_pin__LastLocationOfMaximum, power_8_pin__Minimum, power_consumption_tdp__LastLocationOfMaximum, power_consumption_tdp__MeanSecondDerivativeCentral, power_consumption_tdp__Minimum, power_mvddc__LastLocationOfMaximum, power_mvddc__MeanChange, power_pcie_slot__Minimum, 


    # constans: power_gpu_chip__LargeStandardDeviation