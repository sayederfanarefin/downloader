# pathsInfo = {
#     "powerDataFolder": "F:\\erfan_s_crap\\nvsmi_power_data", 
#     "datasetDir": "F:\\erfan_s_crap\\datasets", 
#     "datasetProfileLogLocation": "F:\\erfan_s_crap\\datasetRecord.csv", 

#     }


pathsInfo = {
    "powerDataFolder": "J:\\Deep Neural Expouser\\nvsmi_power_data", 
    "datasetDir": "J:\\Deep Neural Expouser\\nvsmi-implementation\\datasets", 
    "datasetProfileLogLocation": "J:\\Deep Neural Expouser\\nvsmi-implementation\\datasetRecord.json", 
    "pathToStorePowerDataFile": "J:\\Deep Neural Expouser\\nvsmi-implementation\\pathToStorePowerDataFile.csv", 
    "powerRecordFilePatha": "J:\\Deep Neural Expouser\\nvsmi-implementation\\powerRecordFilePatha.csv", 

    }