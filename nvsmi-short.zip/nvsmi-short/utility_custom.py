import errno
import os, signal
from sys import path
import math
import subprocess
import shutil
import natsort 
import glob


def listReverseNameOrderFIles(pathToFolder, extension):
    os.chdir(pathToFolder)
    dirFiles = glob.glob('*.{}'.format(extension))
    sorted_list = natsort.natsorted(dirFiles,reverse=False)
    #print (sorted_list)
    return sorted_list

def listReverseNameOrderFIlesExtensions(pathToFolder, extensions):
    allFiles = []
    for ext in extensions:
        allFiles.extend(listReverseNameOrderFIles(pathToFolder, ext))
    return allFiles

def truncate(number) -> float:
    digits = 3
    stepper = 10.0 ** digits
    return math.trunc(stepper * number) / stepper

def executeCommanSubProcess(command):
    subprocess.call(command)
    # subprocess.wait()

def execute_command(command):
    # signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    os.system(command)

def remove_file_cmd(pathToFile):
    try:
        os.remove(pathToFile)
    except:
        pass
    # command_builder = "rm -f " + pathToFile
    # execute_command(command_builder)

def createFolder(folderPath):
    try:
        os.makedirs(folderPath)
    except OSError as exc:
        if exc.errno != errno.EEXIST:
            raise
        pass

def moveFile(source, destination):
    try:
        shutil.move(source, destination)
    except:
        pass
# get the size of the folder given in the parameter in bytes
def folderSize(start_path ):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)

    return total_size


#convert files size given in bytes to more suitable unit
def convertSize(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])